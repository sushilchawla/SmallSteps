
import pandas as pd
import datetime
data = pd.read_csv("sphist.csv")
print(data.head(5))
data['Date'] = pd.to_datetime(data['Date'])
data = data.sort_values(by = ['Date'],ascending=True)

r = data['Close'].rolling(window=5)
r_mean = r.mean()
r_30 = data['Close'].rolling(window=30)
r_30_mean = r_30.mean()
r_365 = data['Close'].rolling(window=365)
r_365_mean = r_365.mean()
v = data['Volume'].rolling(window=5)
v_mean = v.mean()
v_365 = data['Volume'].rolling(window=365)
v_365_mean = v_365.mean()
#print(r_mean)
data.shift(periods=1)
data['day_5'] = r_mean
data['day_30'] = r_30_mean
data['day_365'] = r_365_mean
data['v_5'] = v_mean
data['v_365'] = v_365_mean



#print(data.head(5))

print(data.shape)
to_drop = data["Date"] < datetime.datetime(year=1951, month=1, day=3)
print(to_drop.tail(10))
drop_rows = data[to_drop]
print(drop_rows.shape)
df = data.drop(drop_rows.index,axis=0)
print(df.shape)
print(df.isnull().sum())
df = df.dropna(axis=0)
print(df.shape)
train = df[df["Date"] < datetime.datetime(year=2013, month=1, day=1)]
test = df[df["Date"] > datetime.datetime(year=2013, month=1, day=1)]
print(train.shape,test.shape)

# Linearnear regression
features = ['day_5','day_30','day_365','v_5','v_365']
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
import math


lr = LinearRegression()
lr.fit(train[features], train['Close'])
train_predict = lr.predict(train[features])
test_predict = lr.predict(test[features])
train_rmse_2 = math.sqrt(mean_squared_error(train['Close'],train_predict))
test_rmse_2 = math.sqrt(mean_squared_error(test['Close'],test_predict))
print(train_rmse_2,test_rmse_2)
train_mae = mean_absolute_error(train['Close'],train_predict)
test_mae = mean_absolute_error(test['Close'],test_predict)
print(train_mae,test_mae)





